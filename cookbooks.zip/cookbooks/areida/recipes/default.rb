include_recipe 'areida::apt-get-update'
include_recipe 'areida::appserver'
include_recipe 'areida::php'
include_recipe 'areida::services'